-- MySQL dump 10.13  Distrib 8.0.21, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: ProyectoProg
-- ------------------------------------------------------
-- Server version	5.7.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Comentarios`
--

DROP TABLE IF EXISTS `Comentarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Comentarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_post` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `comentario` varchar(500) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idDelPost_comentarios_idx` (`id_post`),
  KEY `idDelUsuario_comentarios_idx` (`id_usuario`),
  CONSTRAINT `idDelPost_comentarios` FOREIGN KEY (`id_post`) REFERENCES `Posts` (`IdPost`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `idDelUsuario_comentarios` FOREIGN KEY (`id_usuario`) REFERENCES `Usuarios` (`IdUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Comentarios`
--

LOCK TABLES `Comentarios` WRITE;
/*!40000 ALTER TABLE `Comentarios` DISABLE KEYS */;
INSERT INTO `Comentarios` VALUES (1,5,5,'que bien la pasan!','2020-12-07'),(2,3,2,'Feliz en su dia!!','2020-12-07'),(98,4,3,'tal cual','2020-12-07'),(99,6,4,'vamo ferroooo','2020-12-07'),(100,7,2,'que picante se pone la premier!!','2020-12-07'),(101,8,3,'hay que aprender a votar !!','2020-12-07'),(102,9,4,'Tremendo. la proxima me anoto!!','2020-12-07'),(103,10,5,'de la mano de Frank los blues dan la vuelta olvidate!!','2020-12-07'),(104,11,2,'lo gana jugando con el kun para pep! en el barca no tiene chances','2020-12-07'),(105,12,3,'tigre equpo chico','2020-12-07'),(106,13,1,'lebron haciendo historia','2020-12-07'),(107,14,3,'le gano la presion. lo inflaron mucho','2020-12-07'),(108,15,4,'estoy de acuerdo','2020-12-07'),(109,16,5,'una bestia!!','2020-12-07'),(110,17,1,'jugadorazo!','2020-12-07'),(111,18,3,'no me gusta nada!!','2020-12-07'),(112,19,4,'que no se deje llevar por el show! que vuelva a ser un niño disfrutando jugar a la pelota y dejando la vida','2020-12-07'),(113,20,5,'serie A la liga menos competitiva... que vuelva el inter y el milan de hace 10 años','2020-12-07'),(114,21,1,'lewan es mucho mas!','2020-12-07'),(115,22,3,'deporte mas aburrido no hay! ','2020-12-07'),(116,23,4,'mucho show! que vuelva jugar el partido y no para las camaras y los microfonos!!','2020-12-07'),(117,24,5,'le queda uno mas por ganar. que mentalidad ganadora por dios!','2020-12-07'),(118,25,1,'partido facil','2020-12-07'),(119,26,2,'se tiene que ir ya! que piense en el una vez. que busce una orejona y un balon de oro mas','2020-12-07'),(120,27,4,'siempre candidato con el muñeco','2020-12-07'),(121,28,5,'momento animico increible. se la llevan','2020-12-07'),(122,29,1,'a griezman le beneficia la ida de messi?? para pensar','2020-12-07'),(123,30,2,'lo gana estrategicamente. olvidate connor se pasa de rosca','2020-12-07');
/*!40000 ALTER TABLE `Comentarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-16 23:01:52
