const bcrypt = require ('bcryptjs');
const db = require('../db/models');
const users = db.Usuario;

const op = db.Sequelize.Op;

let controladorLogin = {
    index: function(req, res){
        return res.render('login');
        },


        login: function(req, res){
            users.findOne({
                where: [{ Nombre_Usuario: req.body.user }]
            })
            .then( function (user) {
                console.log(req.body)
                console.log(user)
                if(user == null) {
                    return res.send("email incorrecto")
                } 
                else if (bcrypt.compareSync(req.body.Password, user.Password) == false) {
                    return res.send("contraseña incorrecta")
                } else if (bcrypt.compareSync(req.body.Password, user.Password) ){
                    
                    req.session.user = user
                    return res.redirect('/home')
                }

            })
            .catch( e => console.log(e))


        },
        
}

module.exports = controladorLogin