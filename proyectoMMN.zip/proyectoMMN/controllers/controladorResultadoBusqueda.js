let rutaResultadoBusqueda = {

    resultadoBusqueda: function(req, res) {
        res.render("resultadoBusqueda", )   
    }
}


module.exports = rutaResultadoBusqueda