let rutaDetallePost = {

    detallePost: function(req, res) {
        res.render("detallePost", )   
    }
}


module.exports = rutaDetallePost