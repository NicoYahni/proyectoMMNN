let rutaDetalleUsuario = {

    detalleUsuario: function(req, res) {
        res.render("detalleUsuario", )   
    }
}


module.exports = rutaDetalleUsuario