let rutaHome = {

    home: function(req, res) {
        res.render("home", )   
    }
}


module.exports = rutaHome
