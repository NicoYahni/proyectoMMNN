let rutaMiPerfil = {

    miPerfil: function(req, res) {
        res.render("miPerfil", )   
    }
}


module.exports = rutaMiPerfil