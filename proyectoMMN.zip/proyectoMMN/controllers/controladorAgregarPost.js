let rutaAgregarPost = {

    agregarPost: function(req, res) {
        res.render("agregarPost", )   
    }
}
 //<form action=""></form>// -->


module.exports = rutaAgregarPost