-- MySQL dump 10.13  Distrib 8.0.21, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: UdesaProg2
-- ------------------------------------------------------
-- Server version	5.7.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Comentarios`
--

DROP TABLE IF EXISTS `Comentarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Comentarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_post` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `comentario` varchar(500) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idDelPost_comentarios_idx` (`id_post`),
  KEY `idDelUsuario_comentarios_idx` (`id_usuario`),
  CONSTRAINT `idDelPost_comentarios` FOREIGN KEY (`id_post`) REFERENCES `Posts` (`IdPost`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `idDelUsuario_comentarios` FOREIGN KEY (`id_usuario`) REFERENCES `Usuarios` (`IdUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Comentarios`
--

LOCK TABLES `Comentarios` WRITE;
/*!40000 ALTER TABLE `Comentarios` DISABLE KEYS */;
INSERT INTO `Comentarios` VALUES (1,5,5,'que bien la pasan!','2020-12-07'),(2,3,2,'Feliz en su dia!!','2020-12-07'),(98,4,3,'tal cual','2020-12-07'),(99,6,4,'vamo ferroooo','2020-12-07'),(100,7,2,'que picante se pone la premier!!','2020-12-07'),(101,8,3,'hay que aprender a votar !!','2020-12-07'),(102,9,4,'Tremendo. la proxima me anoto!!','2020-12-07'),(103,10,5,'de la mano de Frank los blues dan la vuelta olvidate!!','2020-12-07'),(104,11,2,'lo gana jugando con el kun para pep! en el barca no tiene chances','2020-12-07'),(105,12,3,'tigre equpo chico','2020-12-07'),(106,13,1,'lebron haciendo historia','2020-12-07'),(107,14,3,'le gano la presion. lo inflaron mucho','2020-12-07'),(108,15,4,'estoy de acuerdo','2020-12-07'),(109,16,5,'una bestia!!','2020-12-07'),(110,17,1,'jugadorazo!','2020-12-07'),(111,18,3,'no me gusta nada!!','2020-12-07'),(112,19,4,'que no se deje llevar por el show! que vuelva a ser un niño disfrutando jugar a la pelota y dejando la vida','2020-12-07'),(113,20,5,'serie A la liga menos competitiva... que vuelva el inter y el milan de hace 10 años','2020-12-07'),(114,21,1,'lewan es mucho mas!','2020-12-07'),(115,22,3,'deporte mas aburrido no hay! ','2020-12-07'),(116,23,4,'mucho show! que vuelva jugar el partido y no para las camaras y los microfonos!!','2020-12-07'),(117,24,5,'le queda uno mas por ganar. que mentalidad ganadora por dios!','2020-12-07'),(118,25,1,'partido facil','2020-12-07'),(119,26,2,'se tiene que ir ya! que piense en el una vez. que busce una orejona y un balon de oro mas','2020-12-07'),(120,27,4,'siempre candidato con el muñeco','2020-12-07'),(121,28,5,'momento animico increible. se la llevan','2020-12-07'),(122,29,1,'a griezman le beneficia la ida de messi?? para pensar','2020-12-07'),(123,30,2,'lo gana estrategicamente. olvidate connor se pasa de rosca','2020-12-07');
/*!40000 ALTER TABLE `Comentarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Posts`
--

DROP TABLE IF EXISTS `Posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Posts` (
  `IdPost` int(11) NOT NULL AUTO_INCREMENT,
  `Id_usuario` int(11) NOT NULL,
  `Texto_Posteo` varchar(500) DEFAULT NULL,
  `URL` varchar(500) DEFAULT NULL,
  `Fecha_Creacion` date DEFAULT NULL,
  PRIMARY KEY (`IdPost`),
  KEY `idDelUsuario` (`Id_usuario`),
  CONSTRAINT `idDelUsuario` FOREIGN KEY (`Id_usuario`) REFERENCES `Usuarios` (`IdUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Posts`
--

LOCK TABLES `Posts` WRITE;
/*!40000 ALTER TABLE `Posts` DISABLE KEYS */;
INSERT INTO `Posts` VALUES (3,1,'Feliz cumple Isaac!!',NULL,'2020-07-12'),(4,1,'Que tremendo partido de Bokee',NULL,'2020-07-12'),(5,1,'Aca trabajando y comiendo facturas. esto es vida!!',NULL,'2020-07-12'),(6,1,'A 38 años del Bicampeonato de Ferritoo',NULL,'2020-07-12'),(7,1,'Aubameyang al Tottenham, tremendo traidor',NULL,'2020-07-11'),(8,1,'Alberto LRPMQTP!!',NULL,'2020-05-10'),(9,1,'Que lindo dia en el rio con mis amigoss',NULL,'2020-05-11'),(10,1,'El Chelsea va a ganar la Premier',NULL,'2020-05-11'),(11,1,'Messi sexto Balon de Oro, que crack',NULL,'2020-03-09'),(12,1,'Tremenda campaña de Tigre en 2019! Felicitaciones!',NULL,'2020-03-08'),(13,2,'Los Lakers son candidatos al anillo! Paliza a Denver!',NULL,'2020-03-08'),(14,2,'Que fracaso el de Giannis con los Bucks',NULL,'2020-02-01'),(15,2,'Jamal Murray esta on fire',NULL,'2020-02-01'),(16,2,'Jokic es sin dudas el mejor pivot de la liga',NULL,'2020-02-02'),(17,2,'Que puntazo clavo Horton Tucker en la burbuja',NULL,'2020-02-01'),(18,2,'Tremendo crack Michael Porte Jr',NULL,'2020-02-01'),(19,2,'Que jugadorazo Mbappe',NULL,'2020-02-02'),(20,2,'Jugadorazo CR7 en Italia',NULL,'2020-02-02'),(21,2,'Immobile es el mejor 9 del planeta ',NULL,'2020-02-01'),(22,3,'El baseball es el peor deporte del mundo ',NULL,'2020-02-01'),(23,3,'La NBA esta en el mejor momento de su historia',NULL,'2020-02-01'),(24,3,'No puede ser que Cristiano no tenga mas Balones de Oro',NULL,'2020-02-01'),(25,3,'Dale Bocaa, hay que ganarle al DIM',NULL,'2020-04-05'),(26,3,'Tremendo crack Messi eh ',NULL,'2020-04-05'),(27,3,'River es candidato a la Libertadores',NULL,'2020-04-05'),(28,3,'River va a perder la final de la Copa',NULL,'2020-04-08'),(29,3,'Golazo de Messi al Villarreal',NULL,'2020-04-05'),(30,3,'Khabib no tiene chances contra Connor en la revancha',NULL,'2020-04-05'),(31,4,'La UFC es mejor que el boxeo',NULL,'2020-04-07'),(32,4,'Ojala Suarez se retire en la MLS',NULL,'2020-04-08'),(33,4,'Ojala Messi se retire en la MLS',NULL,'2020-04-05'),(34,4,'La MLS va a ser la mejor liga del mundo',NULL,'2020-05-07'),(35,4,'Si Boca le gana a Belgrano tiene chances de ser campeon',NULL,'2020-04-07'),(36,4,'Mbappe es mas que Neymar hoy en dia',NULL,'2020-05-05'),(37,4,'Mbappe es el mejor frances de la historia',NULL,'2020-05-08'),(38,4,'Dale Leoo',NULL,'2020-08-07'),(39,4,'Argentina no tiene chances de ganar un Mundial',NULL,'2020-08-09'),(40,4,'Uruguay nomaaa, dale Lucho Suarez',NULL,'2020-07-07'),(41,5,'Que ganas de que Messi gane otra Champions',NULL,'2020-08-09'),(42,5,'El City va a ganar el SEXTETE, acuerdense',NULL,'2020-06-09'),(43,5,'El Liverpool pincha en 2020',NULL,'2020-07-08'),(44,5,'Dale Boca dale Booo',NULL,'2020-08-09'),(45,5,'Que ganas de jugar un fulbitooo',NULL,'2020-08-09'),(46,5,'El futbol uruguayo tiene mucho nivel',NULL,'2020-08-06'),(47,5,'Uff puntazo del King ',NULL,'2020-09-07'),(48,5,'Que linda es la NBA cuando esta Durant',NULL,'2020-09-07'),(49,5,'Si se arma, Peñarol pelea la Libertadores',NULL,'2020-05-02'),(50,5,'Tremendo jugador Muller',NULL,'2020-07-09'),(51,5,'El Bayern es el club mas grande del mundo',NULL,'2020-08-07');
/*!40000 ALTER TABLE `Posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Usuarios`
--

DROP TABLE IF EXISTS `Usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Usuarios` (
  `IdUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(30) NOT NULL,
  `Apellido` varchar(30) NOT NULL,
  `Nombre_Usuario` varchar(30) NOT NULL,
  `Nacimiento` date NOT NULL,
  PRIMARY KEY (`IdUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Usuarios`
--

LOCK TABLES `Usuarios` WRITE;
/*!40000 ALTER TABLE `Usuarios` DISABLE KEYS */;
INSERT INTO `Usuarios` VALUES (1,'Juan','Rodriguez','juanrodriguez','2000-01-01'),(2,'Pablo','Gutierrez','pablitogutierrez','1995-04-23'),(3,'Juliana','Rakitic','juanitarakitic','1970-09-25'),(4,'Antonella','Messi','antomessi','1965-10-05'),(5,'Nicolas','Minaj','soynikiminaj','1998-11-21');
/*!40000 ALTER TABLE `Usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-28  9:48:37
