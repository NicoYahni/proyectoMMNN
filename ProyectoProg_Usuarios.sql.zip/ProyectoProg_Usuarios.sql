-- MySQL dump 10.13  Distrib 8.0.21, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: ProyectoProg
-- ------------------------------------------------------
-- Server version	5.7.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Usuarios`
--

DROP TABLE IF EXISTS `Usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Usuarios` (
  `IdUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(30) NOT NULL,
  `Apellido` varchar(30) NOT NULL,
  `Nombre_Usuario` varchar(30) NOT NULL,
  `Nacimiento` date NOT NULL,
  `Mail` varchar(45) DEFAULT NULL,
  `Password` varchar(200) NOT NULL,
  `Pregunta_Seguridad` varchar(45) NOT NULL,
  `Respuesta_Seguridad` varchar(200) NOT NULL,
  PRIMARY KEY (`IdUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Usuarios`
--

LOCK TABLES `Usuarios` WRITE;
/*!40000 ALTER TABLE `Usuarios` DISABLE KEYS */;
INSERT INTO `Usuarios` VALUES (1,'Juan','Rodriguez','juanrodriguez','2000-01-01','','','',''),(2,'Pablo','Gutierrez','pablitogutierrez','1995-04-23','','','',''),(3,'Juliana','Rakitic','juanitarakitic','1970-09-25','','','',''),(4,'Antonella','Messi','antomessi','1965-10-05','','','',''),(5,'Nicolas','Minaj','soynikiminaj','1998-11-21','','','',''),(6,'nicolas','yahni','jdjw','2020-11-13',NULL,'123','',''),(7,'marcos','hogg','dfjnd','2020-11-26','yahninicolas@gmail.com','123','',''),(8,'nueva','cuenta','nuevacuenta','2020-11-01','marcos.hogg@gmail.com','jjjjjjj','',''),(9,'marcos','hogg','hogg','2020-10-31','marcos.hogg@gmail.com','$2a$10$7mHM4gKDSKJYwhYiNLOFwO04ViTNbOIKl8BurZv/7dfN0kP47Ox7W','',''),(10,'marcos','hogg','probando','2020-10-29','marcos.hogg@gmail.com','$2a$10$0nfXb8sbmpJfbhEMXvkku.lh1WXH4rKvAiYOrcj/u/lROpMUPPX5i','',''),(11,'marcos','hogg','pruebo','2020-10-29','marcos.hogg@gmail.com','$2a$10$PU3EUSQF05zdF2lVLL8vb.86SWrZIl396EL1ACympMBMETbRWLGee','',''),(12,'marcos','hogg','marqui','2020-10-30','marcos.hogg@gmail.com','$2a$10$PqK.JVn2PS4TV/m8p6pc7eYNbfi.xAMuk6ELUcYJDomOPbEmi4iJW','comidaFavorita','asado'),(13,'mar','hogg','marhogg','2020-11-06','marcos.hogg@gmail.com','$2a$10$qSRucjvvlm5VRk4wSDfAWei.SCuDTbnXIwtQY6FBzlXNUf8LKwtvK','2','pancho'),(14,'marcos','hogg','marqui','2020-10-31','marcos.hogg@gmail.com','$2a$10$/YvBsb3zJCtYhiDC3eBxGO0Eo2ZUB5TYt6O2hDAix8DF1VKh3de8y','3','yerua'),(15,'Juan','Rodriguez','mh','2020-10-29','besapiens1@gmail.com','123','3','casa'),(16,'sigue','tirando','error','2020-10-31','error@error.com','$2a$10$wlgRw1vWva6.m.9/tNbaLuW3IJAFQpGWOxc//NGn.PR0LOtSP7E8O','1','$2a$10$vEA9bn2OeGwNXocq/u0xAuplswAsaHOYRrUSgA/OaSmgIpzoucZP6'),(17,'Juan','Rodriguez','usuario','2020-10-31','besapiens1@gmail.com','nuevaaaa','1','$2a$10$J.gbfO1gjuS.1ocyNGS7q.HsJNOeVqFWSBgsSgWuxuC.A9gNHHwBy'),(18,'pedro','Rodriguez','nuevousuario','2020-10-30','besapiens1@gmail.com','$2a$10$W0b2dy9Zq7Vhfw9W0N1tY.cQdK7iSDhdaPV9706zQKUcnzJKVosiK','1','$2a$10$IOw/kDAXXOqKgMQ..iQM5ubTutcadZB5Z8F8ywHbvOYYbtVamRuRq'),(19,'mark','hogg','m','2020-10-31','marcos.hogg@gmail.com','$2a$10$5VftteQS9tWdouxPJ.65..S5D76eRFlipI9/CeYusoXfVOf2heh4i','1','$2a$10$uDeqVPUiTdgQaqz.7lePXe7tKEIR5GwLiEBYpSSHGk2K4A1z3klMK');
/*!40000 ALTER TABLE `Usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-16 23:01:51
